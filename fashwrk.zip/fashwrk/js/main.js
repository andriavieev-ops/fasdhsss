/* FashWrk — shared behaviour */
const ICON = {
  logo:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 20 16 8"/><path d="m15 4 5 5-3 1-3-3 1-3z"/></svg>',
  ig:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor"/></svg>',
  fb:'<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 0 0-1.6 19.9V15h-2.5v-3h2.5V9.8c0-2.5 1.5-3.9 3.8-3.9 1.1 0 2.2.2 2.2.2v2.5h-1.3c-1.2 0-1.6.8-1.6 1.6V12h2.8l-.4 3h-2.4v6.9A10 10 0 0 0 12 2z"/></svg>',
  bookmark:'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M6 3h12v18l-6-4-6 4z"/></svg>'
};
const PAGES = [['index.html','Home'],['style-finder.html','Style Finder'],['how-it-works.html','How It Works'],['about.html','About'],['contact.html','Contact']];
const current = location.pathname.split('/').pop() || 'index.html';

document.getElementById('site-header').outerHTML = `
<header class="site-header"><nav class="wrap nav">
  <a href="index.html" class="logo">${ICON.logo}FASHWRK</a>
  <button class="burger" aria-label="Menu"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button>
  <ul class="nav-links">
    ${PAGES.map(([h,l])=>`<li><a href="${h}" class="${h===current?'active':''}">${l}</a></li>`).join('')}
    <li><a href="style-finder.html" class="btn btn-gold">Try Style Finder</a></li>
  </ul></nav></header>`;

document.getElementById('site-footer').outerHTML = `
<footer class="site-footer"><div class="wrap">
  <div class="foot-grid">
    <div><a href="index.html" class="logo" style="font-size:16px">${ICON.logo}FASHWRK</a>
      <p style="margin-top:16px">AI-powered personal styling for everyday dressing. Upload a photo, discover new looks — built around the wardrobe you already love.</p>
      <form class="sub-form"><input type="email" placeholder="your@email.com" required><button>Subscribe</button></form></div>
    <div><h4>Visit Us</h4><p>Angeles City, Pampanga<br>Philippines</p><p style="margin-top:10px">Mon – Sat · 10:00 AM – 8:00 PM<br>Sun · 12:00 PM – 6:00 PM</p></div>
    <div><h4>Get In Touch</h4><a href="mailto:hello@fashwrk.com">hello@fashwrk.com</a><br><a href="tel:+639451234567">+63 945 123 4567</a>
      <div class="socials"><a href="#" aria-label="Instagram">${ICON.ig}</a><a href="#" aria-label="Facebook">${ICON.fb}</a></div></div>
  </div>
  <div class="foot-bottom"><span>© ${new Date().getFullYear()} FashWrk. All rights reserved.</span><div><a href="#">Privacy Policy</a><a href="#">Terms of Service</a></div></div>
</div></footer>`;

// Mobile menu
document.querySelector('.burger').onclick = () => document.querySelector('.nav-links').classList.toggle('open');

// Newsletter
document.querySelectorAll('.sub-form').forEach(f => f.addEventListener('submit', e => {
  e.preventDefault(); f.querySelector('button').textContent = 'Subscribed ✓'; f.reset();
}));

// Scroll reveal
const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: .12 });
document.querySelectorAll('.reveal').forEach(el => io.observe(el));

// FAQ accordion
document.querySelectorAll('.faq-item').forEach(item => {
  const a = item.querySelector('.faq-a');
  if (item.classList.contains('open')) a.style.maxHeight = a.scrollHeight + 'px';
  item.querySelector('.faq-q').onclick = () => {
    const open = item.classList.toggle('open');
    a.style.maxHeight = open ? a.scrollHeight + 'px' : 0;
  };
});

// Testimonial slider
const quotes = [
  ['"I always thought I had nothing to wear. Turns out I had everything — I just couldn\'t see it. FashWrk showed me 12 looks I\'d never thought of. I use it every week now."','Ana R.','Fashion Blogger, Cebu','https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&q=80'],
  ['"It spotted a blazer I hadn\'t worn in two years and built five work outfits around it. My mornings are so much easier."','Mika D.','Marketing Lead, Manila','https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&q=80'],
  ['"Finally a style app that doesn\'t just try to sell me more clothes. It made me love my closet again."','Jessa L.','Student, Angeles City','https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=120&q=80']
];
const qEl = document.querySelector('[data-quote]');
if (qEl) {
  const dots = document.querySelector('.dots'); let i = 0;
  const show = n => { i = n; const [t,a,r,img] = quotes[n];
    qEl.style.opacity = 0;
    setTimeout(() => { qEl.textContent = t; document.querySelector('[data-author]').textContent = a;
      document.querySelector('[data-role]').textContent = r; document.querySelector('[data-avatar]').src = img; qEl.style.opacity = 1; }, 250);
    dots.querySelectorAll('button').forEach((d,k) => d.classList.toggle('on', k === n)); };
  dots.innerHTML = quotes.map((_,k) => `<button aria-label="Quote ${k+1}"></button>`).join('');
  dots.querySelectorAll('button').forEach((d,k) => d.onclick = () => show(k));
  qEl.style.transition = 'opacity .25s'; show(0);
  setInterval(() => show((i + 1) % quotes.length), 6000);
}

// Style Finder (demo — simulated AI analysis)
const SAMPLE_RESULTS = [
  { pieces:['Trench Coat · Camel','Wide-Leg Trousers · Olive','Leather Belt · Espresso','Knit Top · Cream'],
    looks:[['Work','Polished Neutral','Trench over the cream knit, trousers belted high, loafers.'],['Weekend','Off-Duty Layers','Knit top with straight jeans, trench draped, white sneakers.'],['Date Night','Soft Tailoring','Olive trousers, black silk cami, belt cinched, gold hoops.']]},
  { pieces:['Blazer · Blush','Button-Down · White','Trousers · Plaid','Tote · Black'],
    looks:[['Work','Modern Power','Blush blazer, white shirt tucked, plaid trousers, black tote.'],['Weekend','Brunch Ready','White shirt knotted over denim shorts, blazer on shoulders.'],['Travel','Airport Chic','Plaid trousers, white tee, sneakers, blazer for the cabin.']]},
  { pieces:['Midi Skirt · Ivory','Blazer · Black','Ankle Boots · Black','Shirt · White'],
    looks:[['Work','Monochrome Edge','Black blazer, white shirt, ivory midi, ankle boots.'],['Date Night','Evening Contrast','Black bodysuit with the ivory midi and strappy heels.'],['Weekend','Easy Elegance','Ivory skirt, striped tee, denim jacket, flats.']]}
];
const dz = document.querySelector('.dropzone');
if (dz) {
  const input = document.getElementById('file'), results = document.querySelector('.results'), dzInner = dz.innerHTML;
  const analyze = (src, idx = Math.floor(Math.random()*3)) => {
    dz.innerHTML = `<img class="dz-preview" src="${src}" alt="Your outfit"><p style="margin-top:12px">Click to upload a different photo</p>`;
    results.classList.add('show');
    results.innerHTML = '<div class="analyzing"><div class="spinner"></div>Detecting garments…</div>';
    results.scrollIntoView({ behavior:'smooth', block:'center' });
    setTimeout(() => { const r = SAMPLE_RESULTS[idx];
      results.innerHTML = `<h3 class="center" style="font-size:24px">We found ${r.pieces.length} pieces</h3>
        <div class="detected">${r.pieces.map(p => { const [n,c] = p.split(' · '); return `<span class="chip">${n} · <b>${c}</b></span>`; }).join('')}</div>
        <div class="look-grid">${r.looks.map(([o,t,d]) => `<div class="look"><span class="occ">${o}</span><h4>${t}</h4><p>${d}</p><button class="save" aria-label="Save look">${ICON.bookmark}</button></div>`).join('')}</div>`;
      results.querySelectorAll('.save').forEach(b => b.onclick = () => b.classList.toggle('on'));
    }, 2200);
  };
  dz.addEventListener('click', () => input.click());
  input.addEventListener('change', () => { const f = input.files[0]; if (f) analyze(URL.createObjectURL(f)); });
  ['dragenter','dragover'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.add('drag'); }));
  ['dragleave','drop'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.remove('drag'); }));
  dz.addEventListener('drop', e => { const f = e.dataTransfer.files[0]; if (f && f.type.startsWith('image/')) analyze(URL.createObjectURL(f)); });
  document.querySelectorAll('[data-sample]').forEach((b,k) => b.onclick = () => {
    document.querySelectorAll('[data-sample]').forEach(x => x.classList.remove('sel')); b.classList.add('sel');
    analyze(b.querySelector('img').src.replace('w=300','w=700'), k % 3);
  });
  const demo = document.querySelector('[data-demo]');
  if (demo) demo.onclick = () => analyze('https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=700&q=80', 0);
}

// Contact form
const cf = document.getElementById('contact-form');
if (cf) cf.addEventListener('submit', e => {
  e.preventDefault(); let ok = true;
  cf.querySelectorAll('[required]').forEach(el => { const bad = !el.value.trim() || (el.type === 'email' && !/^\S+@\S+\.\S+$/.test(el.value));
    el.closest('.field').classList.toggle('err', bad); if (bad) ok = false; });
  if (!ok) return;
  const btn = cf.querySelector('button'); btn.textContent = 'Sending…'; btn.disabled = true;
  setTimeout(() => { cf.reset(); btn.textContent = 'Send Message'; btn.disabled = false;
    const m = cf.querySelector('.form-msg'); m.style.display = 'block'; setTimeout(() => m.style.display = 'none', 5000); }, 1000);
});
